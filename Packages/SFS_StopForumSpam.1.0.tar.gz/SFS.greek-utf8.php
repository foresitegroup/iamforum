<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'Ο χρήστης %s με Email %s (IP %s) είναι Spam, παρακαλούμε επικοινωνήστε με το διαχειριστή του φόρουμ.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Ενεργοποίηση του Stop Forum Spam';
$txt['sfs_txt_sfsenabled_desc'] = 'Ενεργοποίηση ελέγχου αν ο χρήστης ηλεκτρονικού ταχυδρομείου είναι στο www.stopforumspam.com';
$txt['sfs_txt_ipcheck'] = 'Έλεγχος και της διεύθυνσης IP';
$txt['sfs_txt_ipcheck_desc'] = 'Ενεργοποίηση ελέγχου IP';
$txt['sfs_txt_usernamecheck'] = 'Έλεγχος και του ονόματος χρήστη';
$txt['sfs_txt_usernamecheck_desc'] = 'Ενεργοποίηση ελέγχου ονόματος χρήστη';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Ενεργοποίηση του Stop Forum Spam';
$txt['setting_sfs_enabled_desc'] = 'Ενεργοποίηση ελέγχου αν ο χρήστης ηλεκτρονικού ταχυδρομείου είναι στο www.stopforumspam.com';
$txt['setting_sfs_ipcheck'] = 'Έλεγχος και της διεύθυνσης IP';
$txt['setting_sfs_ipcheck_desc'] = 'Ενεργοποίηση ελέγχου IP';
$txt['setting_sfs_usernamecheck'] = 'Έλεγχος και του ονόματος χρήστη';
$txt['setting_sfs_usernamecheck_desc'] = 'Ενεργοποίηση ελέγχου ονόματος χρήστη';
?>
