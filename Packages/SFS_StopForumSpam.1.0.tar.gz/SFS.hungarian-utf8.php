<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'A(z) %s felhasználó a %s e-mail címmel (IP: %s) egy Spam, kérjük lépjen kapcsolatba a fórum adminisztrátorával.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Stop Forum Spam bekapcsolva';
$txt['sfs_txt_sfsenabled_desc'] = 'Felhasználó e-mail címének ellenőrzése ha megtalálható a www.stopforumspam.com website-on';
$txt['sfs_txt_ipcheck'] = 'IP cím ellenőrzése';
$txt['sfs_txt_ipcheck_desc'] = 'IP cím ellenőrzésének bekapcsolása';
$txt['sfs_txt_usernamecheck'] = 'Felhasználónév ellenőrzése';
$txt['sfs_txt_usernamecheck_desc'] = 'Felhasználónév ellenőrzésének bekapcsolása';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Stop Forum Spam bekapcsolva';
$txt['sfs_txt_sfsenabled_desc'] = 'Felhasználó e-mail címének ellenőrzése ha megtalálható a www.stopforumspam.com website-on';
$txt['sfs_txt_ipcheck'] = 'IP cím ellenőrzése';
$txt['sfs_txt_ipcheck_desc'] = 'IP cím ellenőrzésének bekapcsolása';
$txt['sfs_txt_usernamecheck'] = 'Felhasználónév ellenőrzése';
$txt['sfs_txt_usernamecheck_desc'] = 'Felhasználónév ellenőrzésének bekapcsolása';
?>