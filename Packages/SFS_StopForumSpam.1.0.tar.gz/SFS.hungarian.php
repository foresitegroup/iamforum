<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'A(z) %s felhaszn&#225;l&#243; a %s e-mail c�mmel (IP: %s) egy Spam, k&#233;rj�k l&#233;pjen kapcsolatba a f&#243;rum adminisztr&#225;tor&#225;val.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Stop Forum Spam bekapcsolva';
$txt['sfs_txt_sfsenabled_desc'] = 'Felhaszn&#225;l&#243; e-mail c�m&#233;nek ellen&#337;rz&#233;se ha megtal&#225;lhat&#243; a www.stopforumspam.com website-on';
$txt['sfs_txt_ipcheck'] = 'IP c�m ellen&#337;rz&#233;se';
$txt['sfs_txt_ipcheck_desc'] = 'IP c�m ellen&#337;rz&#233;s&#233;nek bekapcsol&#225;sa';
$txt['sfs_txt_usernamecheck'] = 'Felhaszn&#225;l&#243;n&#233;v ellen&#337;rz&#233;se';
$txt['sfs_txt_usernamecheck_desc'] = 'Felhaszn&#225;l&#243;n&#233;v ellen&#337;rz&#233;s&#233;nek bekapcsol&#225;sa';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Stop Forum Spam bekapcsolva';
$txt['sfs_txt_sfsenabled_desc'] = 'Felhaszn&#225;l&#243; e-mail c�m&#233;nek ellen&#337;rz&#233;se ha megtal&#225;lhat&#243; a www.stopforumspam.com website-on';
$txt['sfs_txt_ipcheck'] = 'IP c�m ellen&#337;rz&#233;se';
$txt['sfs_txt_ipcheck_desc'] = 'IP c�m ellen&#337;rz&#233;s&#233;nek bekapcsol&#225;sa';
$txt['sfs_txt_usernamecheck'] = 'Felhaszn&#225;l&#243;n&#233;v ellen&#337;rz&#233;se';
$txt['sfs_txt_usernamecheck_desc'] = 'Felhaszn&#225;l&#243;n&#233;v ellen&#337;rz&#233;s&#233;nek bekapcsol&#225;sa';
?>