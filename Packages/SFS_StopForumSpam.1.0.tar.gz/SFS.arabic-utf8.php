﻿<?php
// Version: 0.1

global $helptxt, $txtJs;

//Sfs
$txt['sfs_spam_detected'] = 'هذا البريد الإلكترونى %s (IP %s) يبدو أنه Spam, يرجى مراسلة صاحب الموقع.';
$txt['sfs_txt_sfsenabled'] = 'تفعيل مود منع ال Spam من التسجيل ؟';
$txt['sfs_txt_sfsenabled_desc'] = 'يقوم بفحص الإيمال الخاص بالمستخدم فى موقع  www.stopforumspam.com و التأكد  من أنه ليس خاص بـ  Spam .';
$txt['sfs_txt_ipcheck'] = 'فحص الـ IP ؟';
$txt['sfs_txt_ipcheck_desc'] = 'يقوم  بفحص الـ IP و التأكد من أنه ليس خاص بـ  Spam .';
$txt['sfs_txt_usernamecheck'] = 'فحص إسم المستخدم ؟؟';
$txt['sfs_txt_usernamecheck_desc'] = 'يقوم بفحص إسم المستخدم للتأكد من أنه ليس خاص بـ Spam .';
?>