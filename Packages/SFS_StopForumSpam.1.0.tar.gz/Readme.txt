Thank you for using Stop Forum Spam Mod.
This Mod verify the user in the registration page with www.stopfroumspam.com
is a spam denied the registration.

Uninstall previous version before install this version

Version 1.0
- Add german language (thanks dom.bn)
- Add croatian language (thanks Mihac™)

Version 0.9
- Add hungarian language (thanks robv)
- Add sfs Icon

Version 0.8
- Add link check to Stop Forum Spam in Who's on line page

Version 0.7
- Add french language (thanks teknautomotive)
- Add greek language (thanks faiza and nikan)
- Add russian language (thanks Bugo)
- Add turkish language (thanks PLAYBOY)
- Add ukrainian language (thanks olex)

Version 0.6
- Upgrade to SMF 2.0 RC4
- Add portuguese language (thanks  Joomlamz)

Version 0.5
- Update language in utf8 encoding
- Add Arabic language (thanks islam2hamy)

Version 0.4
- Redirect to Registration Settings Page
- Enable Check username

Version 0.3
- use fetch_web_data to get response
- change some install step

Version 0.2
- Now can disable/enable the check of IP Address

Version 0.1
! Release

