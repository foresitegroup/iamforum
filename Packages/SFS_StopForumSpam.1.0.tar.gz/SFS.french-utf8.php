<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'L utilisateur %s dont l Email est %s (IP %s) est un Spammeur, merci de contacter l administrateur du Forum.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Stop Forum Spam Actif';
$txt['sfs_txt_sfsenabled_desc'] = 'Activer la verification Email dans www.stopforumspam.com';
$txt['sfs_txt_ipcheck'] = 'Verifier aussi l addresse IP';
$txt['sfs_txt_ipcheck_desc'] = 'Activer la verification d adresse IP';
$txt['sfs_txt_usernamecheck'] = 'Verifier aussi le nom d utilisateur';
$txt['sfs_txt_usernamecheck_desc'] = 'Activer la verification du nom d utilisateur';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Stop Forum Spam Actif';
$txt['setting_sfs_enabled_desc'] = 'Activer la verification Email dans www.stopforumspam.com';
$txt['setting_sfs_ipcheck'] = 'Verifier aussi l addresse IP';
$txt['setting_sfs_ipcheck_desc'] = 'Activer la verification d adresse IP';
$txt['setting_sfs_usernamecheck'] = 'Verifier aussi le nom d utilisateur';
$txt['setting_sfs_usernamecheck_desc'] = 'Activer la verification du nom d utilisateur';
?>
